<?php
header('Location: pages/login');
